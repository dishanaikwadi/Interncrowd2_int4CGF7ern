package org.pk.resume.builder.session;

public class JournalSessionConstant {

	public static String JOURNAL_NAME="journal_name";
	public static String JOURNAL_TYPE="journal_type";
	public static String PAPER_TITLE="paper_title";
	public static String AUTHOR="author";
	public static String DOPUBLICATION="dopublication";
	public static String PLACE="place";
	public static String VOLUME="volume";
	public static String PAGE_N0="page_no";
	public static String DOI_NO="doi_no";
	public static String LINK = "link";
	public static String IMPACT_FACTOR="impact_factor";
	public static String IMPACT_TYPE="impact_type";
	
	
	
}
