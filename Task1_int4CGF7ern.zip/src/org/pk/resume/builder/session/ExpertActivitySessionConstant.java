package org.pk.resume.builder.session;

public class ExpertActivitySessionConstant {

	public static String EXPERT_ROLE = "expert_role";
	public static String LEVEL = "level";
	public static String ACTIVITY_TYPE = "activity_type";
	public static String PLACE = "place";
	public static String ISBN_NO = "isbn_no";
	
}
