package org.pk.resume.builder.session;

public class AchievementSessionConstant 
{
	public static String NAME = "name";
	public static String TITLE = "title";
	public static String PLACE = "place";
	public static String DATE = "date";
	
}
